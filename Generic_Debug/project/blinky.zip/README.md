# Bare-metal blinky example

The Blinky project is a simple bare-metal example for a simulated Arm Cortex-M4
device. It is fully compliant to the CMSIS standard.

The example is compatible with other Arm Cortex-M based devices. To change the
device, go to **Project - Options for Target 'Simulation'...**, switch to the
**Device** tab and select another device.

## Example functionality

- Clore clock = 25 MHz.
- A virtual LED is blinking by setting a global variable to 1 or 0.
- It is configured for a simulated on-chip Flash.
